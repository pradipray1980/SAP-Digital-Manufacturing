/**
 * SFC Genealogy — Supervisor Workbench Edition
 * Two-screen: Summary Dashboard → Component Detail Workbench
 */
sap.ui.define([
    "sap/dm/dme/podfoundation/controller/PluginViewController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/base/Log"
], function (PluginViewController, JSONModel, MessageToast, Log) {
    "use strict";

    var oLogger = Log.getLogger("sfcGenealogy", Log.Level.INFO);

    return PluginViewController.extend("sap.dm.custom.plugin.sfcGenealogy.controller.MainView", {

        onInit: function () {
            if (PluginViewController.prototype.onInit) {
                PluginViewController.prototype.onInit.apply(this, arguments);
            }
            this._initModels();
        },

        _initModels: function () {
            var oModel = new JSONModel({
                sfc: "",
                // flat list for detail workbench
                flatList: [],
                // all processed components (source of truth)
                components: [],
                // summary dashboard data
                operationSummary: [],
                batchSummary: [],
                // KPIs
                totalComponents:   0,
                operationCount:    0,
                uniqueBatchCount:  0,
                serialTrackedCount: 0,
                dataFieldsTotal:   0,
                // state
                isLoading:         false,
                hasData:           false,
                lastRefresh:       null,
                selectedComponent: {},
                selectedOperation: null
            });
            this.getView().setModel(oModel, "genealogy");
        },

        onBeforeRenderingPlugin: function () {
            this.subscribe("PodSelectionChangeEvent", this._onPodSelectionChange, this);
            this.subscribe("phaseSelectionEvent",     this._onWorklistSelect,       this);
            this.subscribe("OperationListSelectEvent", this._onOperationChange,     this);
        },
        onAfterRendering: function () { this._loadGenealogyData(); },
        onExit: function () {
            this.unsubscribe("PodSelectionChangeEvent", this._onPodSelectionChange, this);
            this.unsubscribe("WorklistSelectEvent",     this._onWorklistSelect,      this);
            this.unsubscribe("OperationListSelectEvent", this._onOperationChange,   this);
            if (PluginViewController.prototype.onExit) {
                PluginViewController.prototype.onExit.apply(this, arguments);
            }
        },

        _onPodSelectionChange: function (sChannelId, sEventId, oData) {
            if (this.isEventFiredByThisPlugin(oData)) return;
            this._loadGenealogyData();
        },
        _onWorklistSelect: function (sChannelId, sEventId, oData) {
            if (this.isEventFiredByThisPlugin(oData)) return;
            this._loadGenealogyData();
        },
        _onOperationChange: function (sChannelId, sEventId, oData) {
            if (this.isEventFiredByThisPlugin(oData)) return;
            this._loadGenealogyData();
        },

        _getCurrentSfc: function () {
            var oPod = this.getPodSelectionModel();
            if (!oPod) return null;
            var aSel = oPod.getSelections();
            if (!aSel || !aSel.length) return null;
            var oSel = aSel[0];
            return oSel.getSfc ? oSel.getSfc() : oSel.getInput();
        },
        _getCurrentOperation: function () {
            var oPod = this.getPodSelectionModel();
            if (!oPod) return null;
            var aOps = oPod.getOperations();
            return (aOps && aOps.length) ? aOps[0].operation : null;
        },

        _loadGenealogyData: function () {
            var sSfc = this._getCurrentSfc();
            if (!sSfc) { this._clearData(); return; }

            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/isLoading", true);
            oModel.setProperty("/sfc", sSfc);

            var sPlant = this.getPodController().getUserPlant();
            var sOp    = this._getCurrentOperation();
            if (!sOp) {
                oModel.setProperty("/isLoading", false);
                oModel.setProperty("/hasData", false);
                this.showErrorMessage("Please select an operation to view assembled components", true, false);
                return;
            }

            var sUrl = this.getPublicApiRestDataSourceUri() + "/assembly/v1/assembledComponents"
                + "?plant="              + encodeURIComponent(sPlant)
                + "&sfc="               + encodeURIComponent(sSfc)
                + "&operationActivity="  + encodeURIComponent(sOp);

            oLogger.info("Fetching SFC: " + sSfc + "  Op: " + sOp);
            var that = this;
            this.ajaxGetRequest(sUrl, null,
                function (oResp) { that._processApiResponse(oResp, sSfc); },
                function (oErr)  { that._handleApiError(oErr); }
            );
        },

        _processApiResponse: function (oResponse, sSfc) {
            console.log("API Response:", JSON.stringify(oResponse, null, 2));
            var aRaw = [];
            if (Array.isArray(oResponse)) {
                aRaw = oResponse;
            } else if (oResponse && Array.isArray(oResponse.assembledComponents)) {
                aRaw = oResponse.assembledComponents;
            } else if (oResponse && Array.isArray(oResponse.value)) {
                aRaw = oResponse.value;
            } else if (oResponse && typeof oResponse === "object") {
                for (var k in oResponse) {
                    if (Array.isArray(oResponse[k])) { aRaw = oResponse[k]; break; }
                }
            }

            var aComponents  = this._processComponents(aRaw);
            var oSummary     = this._buildSummary(aComponents);
            var aFlatList    = this._buildFlatList(aComponents);

            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/components",         aComponents);
            oModel.setProperty("/flatList",           aFlatList);
            oModel.setProperty("/operationSummary",   oSummary.operationSummary);
            oModel.setProperty("/batchSummary",       oSummary.batchSummary);
            oModel.setProperty("/totalComponents",    aComponents.length);
            oModel.setProperty("/operationCount",     oSummary.operationSummary.length);
            oModel.setProperty("/uniqueBatchCount",   oSummary.batchSummary.length);
            oModel.setProperty("/serialTrackedCount",    oSummary.serialTrackedCount);
            oModel.setProperty("/inventoryTrackedCount", oSummary.inventoryTrackedCount);
            oModel.setProperty("/inventoryComponents",   oSummary.inventoryComponents);
            oModel.setProperty("/storageLocationCount",  oSummary.storageLocationCount);
            oModel.setProperty("/storageLocations",      oSummary.storageLocations);
            oModel.setProperty("/dataFieldsTotal",    aComponents.reduce(function(s,c){return s+c.dataFieldsCount;},0));
            oModel.setProperty("/hasData",            aComponents.length > 0);
            oModel.setProperty("/isLoading",          false);
            oModel.setProperty("/lastRefresh",        new Date().toLocaleTimeString());
            oModel.setProperty("/selectedComponent",  {});

            // Build batch tiles dynamically
            if (aComponents.length > 0) {
                var that = this;
                setTimeout(function () {
                    that._buildBatchTiles(oSummary.batchSummary);
                    that._decorateFlatListItems();
                }, 0);
            } else {
                MessageToast.show("No assembled components found for this SFC");
            }
        },

        /**
         * Build all summary data structures from processed components
         */
        _buildSummary: function (aComponents) {
            var oOpMap    = {};
            var oOpOrder  = [];
            var oBatchMap = {};
            var aBatchOrder = [];
            var aNoBatch  = [];
            var iSerial   = 0;
            var iInventoryTracked = 0;
            var oStorageLocSet = {};

            aComponents.forEach(function (oComp) {
                // Operations
                var sOp = oComp.operation || "—";
                if (!oOpMap[sOp]) {
                    oOpMap[sOp] = {
                        operation:            sOp,
                        operationDescription: oComp.operationDescription || "",
                        componentCount:       0,
                        batchSet:             {}
                    };
                    oOpOrder.push(sOp);
                }
                oOpMap[sOp].componentCount++;
                if (oComp.batchNumber) oOpMap[sOp].batchSet[oComp.batchNumber] = true;

                // Batches
                if (oComp.batchNumber) {
                    var sBatch = oComp.batchNumber;
                    if (!oBatchMap[sBatch]) {
                        oBatchMap[sBatch] = {
                            batchNumber:  sBatch,
                            components:   [],
                            operations:   {},
                            totalQty:     0,
                            uom:          oComp.unitOfMeasure || ""
                        };
                        aBatchOrder.push(sBatch);
                    }
                    oBatchMap[sBatch].components.push(oComp);
                    oBatchMap[sBatch].operations[oComp.operation] = true;
                    oBatchMap[sBatch].totalQty += parseFloat(oComp.quantityAssembled) || 0;
                } else {
                    aNoBatch.push(oComp);
                }

                // Serial
                if (oComp.serialNumber) iSerial++;
                if (oComp.inventoryId) iInventoryTracked++;
                if (oComp.storageLocation) oStorageLocSet[oComp.storageLocation] = true;
            });

            // Finalize operation summary
            var aOpSummary = oOpOrder.map(function (sOp) {
                var o = oOpMap[sOp];
                return {
                    operation:            o.operation,
                    operationDescription: o.operationDescription,
                    componentCount:       o.componentCount,
                    batchCount:           Object.keys(o.batchSet).length
                };
            });

            // Finalize batch summary
            var aBatchSummary = aBatchOrder.map(function (sBatch) {
                var b = oBatchMap[sBatch];
                return {
                    batchNumber:    b.batchNumber,
                    componentCount: b.components.length,
                    operationCount: Object.keys(b.operations).length,
                    operations:     Object.keys(b.operations).join(", "),
                    totalQty:       b.totalQty,
                    uom:            b.uom,
                    components:     b.components
                };
            });

            // Build inventoryComponents list — only components with an inventoryId
            var aInventoryComponents = aComponents.filter(function (c) { return !!c.inventoryId; });

            return {
                operationSummary:     aOpSummary,
                batchSummary:         aBatchSummary,
                noBatchComponents:    aNoBatch,
                serialTrackedCount:   iSerial,
                inventoryTrackedCount: iInventoryTracked,
                inventoryComponents:  aInventoryComponents,
                storageLocationCount:  Object.keys(oStorageLocSet).length,
                storageLocations:      Object.keys(oStorageLocSet).join(", ")
            };
        },

        /**
         * Dynamically build batch tile FlexBox items
         */
        _buildBatchTiles: function (aBatchSummary) {
            var oContainer = this.byId("batchTilesContainer");
            if (!oContainer) return;
            oContainer.removeAllItems();

            var that = this;
            aBatchSummary.forEach(function (oBatch) {
                // Colour cycle: amber, teal, navy, violet
                var aColors = ["sfcgBatchTileAmber", "sfcgBatchTileTeal", "sfcgBatchTileNavy", "sfcgBatchTileViolet"];
                var sColor  = aColors[aBatchSummary.indexOf(oBatch) % aColors.length];

                var oTile = new sap.m.VBox({
                    items: [
                        new sap.m.HBox({
                            alignItems: "Center",
                            items: [
                                new sap.ui.core.Icon({ src: "sap-icon://tag" }).addStyleClass("sfcgBatchTileIcon"),
                                new sap.m.Text({ text: oBatch.batchNumber }).addStyleClass("sfcgBatchTileId")
                            ]
                        }),
                        new sap.m.HBox({
                            wrap: "Wrap",
                            items: [
                                new sap.m.VBox({
                                    items: [
                                        new sap.m.Text({ text: String(oBatch.componentCount) }).addStyleClass("sfcgBatchTileStat"),
                                        new sap.m.Text({ text: "parts" }).addStyleClass("sfcgBatchTileStatLabel")
                                    ]
                                }).addStyleClass("sfcgBatchTileStatBox"),
                                new sap.m.VBox({
                                    items: [
                                        new sap.m.Text({ text: String(oBatch.operationCount) }).addStyleClass("sfcgBatchTileStat"),
                                        new sap.m.Text({ text: "ops" }).addStyleClass("sfcgBatchTileStatLabel")
                                    ]
                                }).addStyleClass("sfcgBatchTileStatBox"),
                                new sap.m.VBox({
                                    items: [
                                        new sap.m.Text({ text: String(oBatch.totalQty) + " " + oBatch.uom }).addStyleClass("sfcgBatchTileStat"),
                                        new sap.m.Text({ text: "total qty" }).addStyleClass("sfcgBatchTileStatLabel")
                                    ]
                                }).addStyleClass("sfcgBatchTileStatBox")
                            ]
                        }).addStyleClass("sfcgBatchTileStats"),
                        new sap.m.Text({ text: "Used in: " + oBatch.operations }).addStyleClass("sfcgBatchTileOps"),
                        new sap.m.Button({
                            text: "View " + oBatch.componentCount + " component" + (oBatch.componentCount !== 1 ? "s" : "") + " →",
                            type: "Transparent",
                            press: function () {
                                that._navigateToDetailWithBatchFilter(oBatch.batchNumber);
                            }
                        }).addStyleClass("sfcgBatchTileBtn")
                    ]
                }).addStyleClass("sfcgBatchTile " + sColor);

                oContainer.addItem(oTile);
            });
        },

        // ── Navigation ────────────────────────────────────

        onViewDetailPress: function () {
            // Clear any batch filter — show all components
            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/flatList", this._buildFlatList(oModel.getProperty("/components")));
            oModel.setProperty("/selectedComponent", {});
            var oNav = this.byId("navContainer");
            if (oNav) oNav.to(this.byId("detailPage"));
            var that = this;
            setTimeout(function () { that._decorateFlatListItems(); }, 100);
        },

        _navigateToDetailWithBatchFilter: function (sBatchNumber) {
            var oModel      = this.getView().getModel("genealogy");
            var aAll        = oModel.getProperty("/components") || [];
            var aFiltered   = aAll.filter(function (c) { return c.batchNumber === sBatchNumber; });
            oModel.setProperty("/flatList", this._buildFlatList(aFiltered));
            oModel.setProperty("/selectedComponent", {});
            var oNav = this.byId("navContainer");
            if (oNav) oNav.to(this.byId("detailPage"));
            var that = this;
            setTimeout(function () { that._decorateFlatListItems(); }, 100);
        },

        onOperationTilePress: function (oEvent) {
            var oCtx  = oEvent.getSource().getBindingContext("genealogy");
            if (!oCtx) return;
            var oOp   = oCtx.getObject();
            var oModel = this.getView().getModel("genealogy");
            var aAll  = oModel.getProperty("/components") || [];
            var aFiltered = aAll.filter(function (c) { return c.operation === oOp.operation; });
            oModel.setProperty("/flatList", this._buildFlatList(aFiltered));
            oModel.setProperty("/selectedComponent", {});
            var oNav = this.byId("navContainer");
            if (oNav) oNav.to(this.byId("detailPage"));
            var that = this;
            setTimeout(function () { that._decorateFlatListItems(); }, 100);
        },

        onInventoryRowPress: function (oEvent) {
            var oCtx  = oEvent.getSource().getBindingContext("genealogy");
            if (!oCtx) return;
            var oComp = oCtx.getObject();
            var oModel = this.getView().getModel("genealogy");
            // Restore full flat list then navigate to detail with component pre-selected
            oModel.setProperty("/flatList", this._buildFlatList(oModel.getProperty("/components")));
            oModel.setProperty("/selectedComponent", jQuery.extend(true, {}, oComp));
            var oNav = this.byId("navContainer");
            if (oNav) oNav.to(this.byId("detailPage"));
            var that = this;
            setTimeout(function () { that._decorateFlatListItems(); }, 100);
        },

        onNavBack: function () {
            var oNav = this.byId("navContainer");
            if (oNav) oNav.back();
            // Reset search field
            var oSearch = this.byId("searchField");
            if (oSearch) oSearch.setValue("");
            // Restore full flat list
            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/flatList", this._buildFlatList(oModel.getProperty("/components")));
        },

        // ── Workbench interactions ──────────────────────

        onComponentCardPress: function (oEvent) {
            var oSource = oEvent.getSource();
            var oCtx    = oSource.getBindingContext("genealogy");
            if (!oCtx) return;
            var oComp = oCtx.getObject();
            if (!oComp || oComp.itemType !== "component") return;

            var oList = this.byId("flatList");
            if (oList) {
                oList.getItems().forEach(function (oItem) {
                    var dom = oItem.getDomRef ? oItem.getDomRef() : null;
                    if (dom) dom.classList.remove("sfcgCardSelected");
                });
            }
            var dom = oSource.getDomRef ? oSource.getDomRef() : null;
            if (dom) dom.classList.add("sfcgCardSelected");

            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/selectedComponent", jQuery.extend(true, {}, oComp));
        },

        onFilterChange: function (oEvent) {
            var sQ    = (oEvent.getParameter("newValue") || "").toLowerCase();
            var oModel = this.getView().getModel("genealogy");
            var aAll  = oModel.getProperty("/components") || [];
            var aFiltered = sQ
                ? aAll.filter(function (c) {
                    return (c.component    || "").toLowerCase().indexOf(sQ) !== -1 ||
                           (c.description  || "").toLowerCase().indexOf(sQ) !== -1 ||
                           (c.batchNumber  || "").toLowerCase().indexOf(sQ) !== -1 ||
                           (c.serialNumber    || "").toLowerCase().indexOf(sQ) !== -1 ||
                           (c.inventoryId     || "").toLowerCase().indexOf(sQ) !== -1 ||
                           (c.storageLocation || "").toLowerCase().indexOf(sQ) !== -1;
                  })
                : aAll;
            oModel.setProperty("/flatList", this._buildFlatList(aFiltered));
            var that = this;
            setTimeout(function () { that._decorateFlatListItems(); }, 0);
        },

        // ── Data helpers ───────────────────────────────

        _processComponents: function (aRaw) {
            return aRaw.map(function (oComp, i) {
                var aFields = oComp.assemblyDataFields || oComp.dataFields || [];
                var oMap = {};
                aFields.forEach(function (f) {
                    var n = f.fieldName || f.name || f.attribute;
                    var v = f.fieldValue || f.value;
                    if (n) oMap[n] = v;
                });
                var sDate = oComp.assembledDate || oComp.assembledDateTime || oComp.createdDateTime || "";
                if (sDate) { try { sDate = new Date(sDate).toLocaleString(); } catch(e){} }
                return {
                    id:                   i + 1,
                    itemType:             "component",
                    component:            oComp.component || oComp.material || oComp.componentMaterial || "",
                    componentVersion:     oComp.componentVersion || oComp.materialVersion || "",
                    description:          oComp.componentDescription || oComp.description || oComp.materialDescription || "",
                    operation:            oComp.operationActivity || oComp.operation || oComp.assemblyOperation || "",
                    operationDescription: oComp.operationDescription || oComp.operationActivityDescription || "",
                    sequence:             oComp.sequence || oComp.assemblySequence || (i + 1),
                    quantityAssembled:    oComp.assembledQuantity || oComp.quantityAssembled || oComp.qty || oComp.quantity || 0,
                    unitOfMeasure:        oComp.unitOfMeasure || oComp.uom || oComp.unit || "",
                    assembledDateTime:    sDate,
                    assembledBy:          oComp.assembledBy || oComp.userId || oComp.modifiedBy || oComp.createdBy || "",
                    sfcAssembled:         oComp.sfcAssembled || oComp.assembledSfc || oComp.childSfc || "",
                    batchNumber:          oComp.batchNumber || "",
                    serialNumber:         oComp.serialNumber || oMap["SERIAL_NUMBER"] || oMap["ERP_SERIAL_NUMBER"] || "",
                    vendorBatchNumber:    oComp.vendorBatchNumber || oMap["VENDOR_BATCH"] || "",
                    inventoryId:          oComp.inventoryId || "",
                    storageLocation:      oComp.storageLocation || "",
                    handlingUnit:         oComp.handlingUnit || "",
                    assemblyDataType:     oComp.assemblyDataType || "",
                    assemblyDataFields:   aFields,
                    hasDataFields:        aFields.length > 0,
                    dataFieldsCount:      aFields.length
                };
            });
        },

        _buildFlatList: function (aComponents) {
            var oGroups = {}, aOrder = [];
            aComponents.forEach(function (c) {
                var sOp = c.operation || "—";
                if (!oGroups[sOp]) {
                    oGroups[sOp] = { itemType:"header", operation:sOp,
                        operationDescription: c.operationDescription || "", componentCount:0 };
                    aOrder.push(sOp);
                }
                oGroups[sOp].componentCount++;
            });
            var aFlat = [];
            aOrder.forEach(function (sOp) {
                aFlat.push(oGroups[sOp]);
                aComponents.filter(function(c){ return (c.operation||"—")===sOp; })
                           .forEach(function(c){ aFlat.push(c); });
            });
            return aFlat;
        },

        _decorateFlatListItems: function () {
            var oList = this.byId("flatList");
            if (!oList) return;
            var aItems    = oList.getItems();
            var aFlatData = this.getView().getModel("genealogy").getProperty("/flatList") || [];
            var nLen      = Math.min(aItems.length, aFlatData.length);
            for (var i = 0; i < nLen; i++) {
                var dom = aItems[i].getDomRef ? aItems[i].getDomRef() : null;
                if (!dom) continue;
                if (aFlatData[i].itemType === "header") {
                    dom.classList.add("sfcgListItemHeader");
                    dom.classList.remove("sfcgListItemCard", "sfcgCardLastInGroup");
                } else {
                    dom.classList.add("sfcgListItemCard");
                    dom.classList.remove("sfcgListItemHeader");
                    var bLast = (i === nLen - 1) || (aFlatData[i+1] && aFlatData[i+1].itemType === "header");
                    dom.classList.toggle("sfcgCardLastInGroup", bLast);
                }
            }
        },

        _handleApiError: function (oError) {
            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/isLoading", false);
            oModel.setProperty("/hasData",   false);
            var sMsg = (oError && oError.message) ? oError.message : "Error loading genealogy data";
            oLogger.error("API Error:", oError);
            this.showErrorMessage(sMsg, true, true);
        },

        _clearData: function () {
            var oModel = this.getView().getModel("genealogy");
            oModel.setProperty("/sfc",               "");
            oModel.setProperty("/flatList",           []);
            oModel.setProperty("/components",         []);
            oModel.setProperty("/operationSummary",   []);
            oModel.setProperty("/batchSummary",       []);
            oModel.setProperty("/noBatchComponents",  []);
            oModel.setProperty("/totalComponents",    0);
            oModel.setProperty("/operationCount",     0);
            oModel.setProperty("/uniqueBatchCount",   0);
            oModel.setProperty("/serialTrackedCount", 0);
            oModel.setProperty("/noBatchCount",       0);
            oModel.setProperty("/dataFieldsTotal",    0);
            oModel.setProperty("/hasData",            false);
            oModel.setProperty("/isLoading",          false);
            oModel.setProperty("/selectedComponent",  {});
        },

        onRefreshPress: function () { this._loadGenealogyData(); },

        onExportPress: function () {
            var oModel = this.getView().getModel("genealogy");
            var aComps = oModel.getProperty("/components");
            if (!aComps || !aComps.length) { MessageToast.show("No data to export"); return; }
            var sSfc = oModel.getProperty("/sfc");
            this._downloadCsv(this._generateCsv(aComps), "SFC_Genealogy_" + sSfc + ".csv");
        },

        _generateCsv: function (aC) {
            var hdr = ["Component","Version","Description","Operation","Quantity","UoM",
                       "Assembled DateTime","Assembled By","Batch Number","Serial Number","Data Fields"];
            var rows = [hdr.join(",")];
            aC.forEach(function (c) {
                var flds = (c.assemblyDataFields||[]).map(function(f){
                    return (f.fieldName||f.name)+"="+(f.fieldValue||f.value);
                }).join("; ");
                rows.push(['"'+(c.component||"")+'"','"'+(c.componentVersion||"")+'"',
                    '"'+(c.description||"")+'"','"'+(c.operation||"")+'"',
                    c.quantityAssembled||0,'"'+(c.unitOfMeasure||"")+'"',
                    '"'+(c.assembledDateTime||"")+'"','"'+(c.assembledBy||"")+'"',
                    '"'+(c.batchNumber||"")+'"','"'+(c.serialNumber||"")+'"','"'+flds+'"'
                ].join(","));
            });
            return rows.join("\n");
        },

        _downloadCsv: function (sContent, sFilename) {
            var blob = new Blob([sContent], {type:"text/csv;charset=utf-8;"});
            var a = document.createElement("a");
            a.href = URL.createObjectURL(blob); a.download = sFilename; a.click();
            URL.revokeObjectURL(a.href);
            MessageToast.show("Export completed");
        },

        onClosePress: function () { this.closePlugin(); },

        // backward-compat stubs
        onComponentRowPress:  function (e) { this.onComponentCardPress(e); },
        onCloseDetailsDialog: function () { if (this._oDetailsDialog) this._oDetailsDialog.close(); },
        onDataFieldsPress:    function () {},
        onExpandAll:          function () {},
        onCollapseAll:        function () {},
        onTreeItemSelect:     function () {}
    });
});
